package dao;

public interface TestUserDao {
}
