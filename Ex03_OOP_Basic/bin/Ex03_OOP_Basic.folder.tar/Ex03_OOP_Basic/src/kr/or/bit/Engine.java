package kr.or.bit;

public class Engine {
   public int wire=2;
}
