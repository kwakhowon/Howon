package kr.or.bit;

public class Car2 {
	public int door =4;
	public Engine e = new Engine();
}
