import kr.or.bit.Car2;

public class Ex10_init_Class {
	public static void main(String[] args) {
		Car2 c = new Car2();
		System.out.println(c.e.wire);

	}

}
